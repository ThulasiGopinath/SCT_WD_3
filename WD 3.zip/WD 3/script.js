// Game variables
let board;
let currentPlayer = 'X'; // Player starts as 'X'
let gameOver = false;
let isAIEnabled = false;
let aiPlayer = 'O'; // AI plays 'O'

// Create the game board
function createBoard() {
    const gameBoard = document.getElementById('game-board');
    gameBoard.innerHTML = '';
    board = [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ];

    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            const square = document.createElement('div');
            square.classList.add('square');
            square.dataset.row = row;
            square.dataset.col = col;
            square.addEventListener('click', () => handleClick(row, col));
            gameBoard.appendChild(square);
        }
    }
}

// Handle player click
function handleClick(row, col) {
    if (board[row][col] !== '' || gameOver) return;
    board[row][col] = currentPlayer;
    document.querySelector(`[data-row="${row}"][data-col="${col}"]`).textContent = currentPlayer;
    if (checkWin(currentPlayer)) {
        document.getElementById('result').textContent = `${currentPlayer} Wins!`;
        gameOver = true;
        return;
    }
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    document.getElementById('current-player').textContent = `Current Player: ${currentPlayer}`;
    
    if (isAIEnabled && currentPlayer === aiPlayer) {
        setTimeout(aiMove, 500);
    }
}

// Check if a player has won
function checkWin(player) {
    // Check rows, columns, and diagonals
    for (let i = 0; i < 3; i++) {
        if (board[i][0] === player && board[i][1] === player && board[i][2] === player) return true;
        if (board[0][i] === player && board[1][i] === player && board[2][i] === player) return true;
    }
    if (board[0][0] === player && board[1][1] === player && board[2][2] === player) return true;
    if (board[0][2] === player && board[1][1] === player && board[2][0] === player) return true;
    return false;
}

// Restart the game
function restartGame() {
    currentPlayer = 'X';
    gameOver = false;
    document.getElementById('result').textContent = '';
    document.getElementById('current-player').textContent = `Current Player: ${currentPlayer}`;
    createBoard();
}

// Toggle AI mode
function toggleAI() {
    isAIEnabled = !isAIEnabled;
    const button = document.getElementById('toggle-ai-btn');
    button.textContent = isAIEnabled ? 'Play Against Human' : 'Play Against AI';
    restartGame();
}

// AI move logic (Random AI move for now)
function aiMove() {
    if (gameOver) return;
    
    let availableMoves = [];
    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            if (board[row][col] === '') {
                availableMoves.push({ row, col });
            }
        }
    }
    
    if (availableMoves.length > 0) {
        const randomMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
        handleClick(randomMove.row, randomMove.col);
    }
}

// Initialize the game
createBoard();

